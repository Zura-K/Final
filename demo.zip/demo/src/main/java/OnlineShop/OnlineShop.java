package OnlineShop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineShop {

    public static void main(String[] args) {
        SpringApplication.run(OnlineShop.class, args);
    }

}
